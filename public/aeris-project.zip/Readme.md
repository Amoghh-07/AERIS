# AERIS Rescue Command Center

**See the unseen. Act before it is too late.**

AERIS is an AI-assisted disaster-response drone command-center prototype. It simulates multi-drone telemetry, thermal/computer-vision victim triage, missing-person matching, calamity escalation forecasting, animal rescue, and drone-to-victim first-aid communication.

> AERIS is a simulation/prototype, not a live drone-control system.

## Features

- Multi-drone command dashboard with live simulated telemetry
- Tactical disaster-zone map and drone tracking
- Victim triage with dynamic priority changes
- Human and animal rescue workflows
- Missing-person database and simulated face matching
- Drone camera/thermal feed interface
- Drone-to-victim audio communication and first-aid guidance
- Telemedicine communication interface
- Dynamic calamity severity and escalation reporting
- Gemini-powered analysis when an API key is configured
- Built-in resilience fallbacks when Gemini is unavailable

## Run locally

Requirements: Node.js 20.19+ recommended.

```bash
npm install
npm run lint
npm run build
npm run dev
```

Open the local URL printed by the server (normally `http://localhost:3000`).

## Gemini API key

Gemini is **optional**. The dashboard and simulation can run using AERIS fallback responses without a key.

To enable live Gemini analysis, copy `.env.example` to `.env` and set:

```env
GEMINI_API_KEY=your_key_here
```

Never commit `.env` or expose the key in frontend code.

## Production

The project uses an Express server for API routes and Vite for the React frontend. Deploy it to a Node-compatible service. Set `NODE_ENV=production`, provide `GEMINI_API_KEY` if live AI is desired, run `npm run build`, and start with `npm start`.

## Disclaimer

AERIS is a conceptual prototype built for demonstration purposes. Facial identification, medical guidance, telemetry, and rescue operations are simulated and would require appropriate safety, privacy, legal, and human-oversight frameworks before real-world use.
